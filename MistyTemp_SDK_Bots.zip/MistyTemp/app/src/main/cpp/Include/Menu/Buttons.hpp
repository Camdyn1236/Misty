#pragma once
#include <BNMResolve.hpp>
#include <functional>
#include <string>
#include "ButtonInfo.hpp"
#include "Settings.hpp"
#include "../NotiLib/NotiLib.hpp"
#include "../ModInclude.hpp"

using namespace BNM;
using namespace BNM::IL2CPP;
using namespace BNM::Structures;

class Buttons {
public:
    static inline std::vector<std::vector<ButtonInfo>> buttons = {
            {//main stuff - 0
                    ButtonInfo {.buttonText = "Settings", .method = []() { Settings::setCurrentCategory(1); }, .isTogglable = false, .toolTip = "Opens the settings"},
                    ButtonInfo {.buttonText = "Movement", .method = []() { Settings::setCurrentCategory(2); }, .isTogglable = false, .toolTip = "Opens movement"},
                    ButtonInfo {.buttonText = "Player", .method = []() { Settings::setCurrentCategory(3); }, .isTogglable = false, .toolTip = "Opens player"},
                    ButtonInfo {.buttonText = "Overpowered", .method = []() { Settings::setCurrentCategory(4); }, .isTogglable = false, .toolTip = "Opens overpowered"},
                    ButtonInfo {.buttonText = "Bots", .method = []() { Settings::setCurrentCategory(7); }, .isTogglable = false, .toolTip = "Photon bots controller"},
                    ButtonInfo {.buttonText = "Credits", .method = []() { Settings::setCurrentCategory(5); }, .isTogglable = false, .toolTip = "Opens the cedits"},
                    ButtonInfo {.buttonText = "Cool people", .method = []() { Settings::setCurrentCategory(6); }, .isTogglable = false, .toolTip = "Opens the cool people page"},
            },
            {//Settings - 1
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Right hand menu", .enableMethod = []() { Settings::rightHanded = true; }, .disableMethod = []() { Settings::rightHanded = false; }, .toolTip = "Sets the menu to right hand"},
                    ButtonInfo {.buttonText = "Notifications", .enableMethod = []() { NotiLib::SetEnabled(true); }, .disableMethod = []() { NotiLib::SetEnabled(false); }, .enabled = true, .toolTip = "Toggles the notifications"},
                    ButtonInfo {.buttonText = "Disconnect button", .enableMethod = []() { Settings::disconnectButton = true; }, .disableMethod = []() { Settings::disconnectButton = false; }, .enabled = true, .toolTip = "Toggles the disconnect button"},
            },
            {//Movement - 2
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Platforms", .method = []() { Movement::platforms(); }, .toolTip = "Platforms"},
                    ButtonInfo {.buttonText = "Hand Fly", .method = []() { Movement::HandFly(); }, .toolTip = "Hand Fly"},
                    ButtonInfo {.buttonText = "Long Arms", .method = []() { Movement::Longarms(true); }, .toolTip = "Long Arm"},
                    ButtonInfo {.buttonText = "Car", .method = []() { Movement::Car(); }, .toolTip = "Car"},
                    ButtonInfo {.buttonText = "Slingshot Fly", .method = []() { Movement::SlingshotFly(); }, .toolTip = "Slingshot Fly"},
                    },
            {//Player - 3
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "TempName1", .method = []() { PlayerMods::TempName1(); }, .toolTip = "Temp"},
                    ButtonInfo {.buttonText = "TempName2", .method = []() { PlayerMods::TempName2(); }, .toolTip = "Temp"},
                    ButtonInfo {.buttonText = "TempName3", .method = []() { PlayerMods::TempName3(); }, .toolTip = "Temp"},
                    ButtonInfo {.buttonText = "TempName4", .method = []() { PlayerMods::TempName4(); }, .toolTip = "Temp"},
            },
            {//Overpowered - 4
                    ButtonInfo {.buttonText = "back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Crash All (RT)", .method = []() { OverpoweredMods::CrashAll(); }, .toolTip = "Crash All"},
                    ButtonInfo {.buttonText = "Always Master", .method = []() { OverpoweredMods::SetMaster(); }, .toolTip = "Set Master"},
                    },
            {//Credits - 5
                    ButtonInfo {.buttonText = "back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Glitch", .isTogglable = false, .toolTip = "Ported the menu from iiDk's template and the dev of this menu"},
                    ButtonInfo {.buttonText = "Ossuary", .isTogglable = false, .toolTip = "Taught me how to mod :D"},
                    ButtonInfo {.buttonText = "Pubert", .isTogglable = false, .toolTip = "Helped me a lot with the code"},
                    ButtonInfo {.buttonText = "Notfishvr", .isTogglable = false, .toolTip = "Helped me a lot debugging"},
            },
            {//Cool people - 6
                    ButtonInfo {.buttonText = "back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
                    ButtonInfo {.buttonText = "TempName", .isTogglable = false, .toolTip = "Cool person :D"},
            },
            {//Bots - 7  (Photon bot controls)
                    ButtonInfo {.buttonText = "Back", .method = []() { Settings::setCurrentCategory(0); }, .isTogglable = false, .toolTip = "Goes back to main menu"},
                    ButtonInfo {.buttonText = "Spawn Bots", .method = []() { BotMods::SpawnBots(); }, .isTogglable = false, .toolTip = "Spawn photon bots around you"},
                    ButtonInfo {.buttonText = "Clear Bots", .method = []() { BotMods::ClearBots(); }, .isTogglable = false, .toolTip = "Remove all bots"},
                    ButtonInfo {.buttonText = "Remove Some", .method = []() { BotMods::RemoveSome(); }, .isTogglable = false, .toolTip = "Remove botCount bots"},
                    ButtonInfo {.buttonText = "Cycle Mode", .method = []() { BotMods::CycleMode(); }, .isTogglable = false, .toolTip = "Orbit/Follow/Spaz/Formation/Bee/Freeze/P777"},
                    ButtonInfo {.buttonText = "Mode Orbit", .method = []() { BotMods::SetMode(0); }, .isTogglable = false, .toolTip = "Orbit movement"},
                    ButtonInfo {.buttonText = "Mode Follow", .method = []() { BotMods::SetMode(1); }, .isTogglable = false, .toolTip = "Follow movement"},
                    ButtonInfo {.buttonText = "Mode Spaz", .method = []() { BotMods::SetMode(2); }, .isTogglable = false, .toolTip = "Spaz movement"},
                    ButtonInfo {.buttonText = "Mode Formation", .method = []() { BotMods::SetMode(3); }, .isTogglable = false, .toolTip = "Formation movement"},
                    ButtonInfo {.buttonText = "Mode Bee Swarm", .method = []() { BotMods::SetMode(4); }, .isTogglable = false, .toolTip = "Bee swarm movement"},
                    ButtonInfo {.buttonText = "Mode Freeze", .method = []() { BotMods::SetMode(5); }, .isTogglable = false, .toolTip = "Freeze bots in place"},
                    ButtonInfo {.buttonText = "Mode P777", .method = []() { BotMods::SetMode(6); }, .isTogglable = false, .toolTip = "P777 movement"},
                    ButtonInfo {.buttonText = "Count +", .method = []() { BotMods::IncCount(); }, .isTogglable = false, .toolTip = "Increase bot count"},
                    ButtonInfo {.buttonText = "Count -", .method = []() { BotMods::DecCount(); }, .isTogglable = false, .toolTip = "Decrease bot count"},
                    ButtonInfo {.buttonText = "Radius +", .method = []() { BotMods::IncRadius(); }, .isTogglable = false, .toolTip = "Increase orbit radius"},
                    ButtonInfo {.buttonText = "Radius -", .method = []() { BotMods::DecRadius(); }, .isTogglable = false, .toolTip = "Decrease orbit radius"},
                    ButtonInfo {.buttonText = "Bob Up/Down", .enableMethod = []() { BotMods::bobUpDown = true; }, .disableMethod = []() { BotMods::bobUpDown = false; }, .toolTip = "Vertical bob"},
                    ButtonInfo {.buttonText = "Spin Effect", .enableMethod = []() { BotMods::spinEffect = true; }, .disableMethod = []() { BotMods::spinEffect = false; }, .toolTip = "Spin effect flag"},
                    ButtonInfo {.buttonText = "Rainbow", .enableMethod = []() { BotMods::rainbow = true; }, .disableMethod = []() { BotMods::rainbow = false; }, .toolTip = "Rainbow color flag"},
            },
    };
};